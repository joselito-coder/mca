To get invited to ani-cli matrix space send an email to `8klv0leh7 at mozmail.com` with the following contents:
```
Subject: ani-cli matrix space invite
Body: @yourusername:matrixserver
```

It might take some time before you get invited.
