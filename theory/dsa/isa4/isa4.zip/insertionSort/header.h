#include <stdlib.h>
#include "arrayPrinter.h"

// Define some constants
#define ARRAY_SIZE 7

void insertionSort(int arr[], int n);